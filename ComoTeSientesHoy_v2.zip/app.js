const canvas=document.getElementById('canvas');
const ctx=canvas.getContext('2d');
let color='yellow';
let pintar=false;

function setColor(c){color=c;}

function cargarEmocion(e){
 const preguntas={
 feliz:'¿Qué te hizo feliz hoy?',
 triste:'¿Qué pasó para sentirte triste?',
 enojado:'¿Qué te molestó?',
 calmado:'¿Qué te ayuda a sentirte tranquilo?'
 };
 document.getElementById('titulo').innerText='Emoción: '+e;
 document.getElementById('pregunta').innerText=preguntas[e];
 ctx.clearRect(0,0,canvas.width,canvas.height);
 ctx.lineWidth=6;
 ctx.strokeStyle='#000';
 ctx.beginPath();

 if(e==='feliz'){ctx.arc(250,180,90,0,Math.PI*2);}
 if(e==='triste'){ctx.arc(250,180,90,0,Math.PI*2);}
 if(e==='enojado'){ctx.rect(170,100,160,160);}
 if(e==='calmado'){ctx.arc(250,180,90,0,Math.PI*2);}

 ctx.stroke();
}

canvas.addEventListener('mousedown',()=>pintar=true);
canvas.addEventListener('mouseup',()=>pintar=false);
canvas.addEventListener('mousemove',dibujar);

function dibujar(e){
 if(!pintar)return;
 const r=canvas.getBoundingClientRect();
 ctx.fillStyle=color;
 ctx.beginPath();
 ctx.arc(e.clientX-r.left,e.clientY-r.top,10,0,Math.PI*2);
 ctx.fill();
}
